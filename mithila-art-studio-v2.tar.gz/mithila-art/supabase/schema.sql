-- ============================================================
-- Mithila Art & Knitting — Supabase Schema
-- Run this in the Supabase SQL Editor to initialize your DB
-- ============================================================

-- Enable UUID generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- 1. PRODUCTS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS products (
  id              UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  title           TEXT          NOT NULL,
  description     TEXT          NOT NULL,
  story           TEXT,                                          -- Cultural symbolism / artist's note
  price           NUMERIC(10,2) NOT NULL CHECK (price >= 0),
  category        TEXT          NOT NULL CHECK (category IN ('mithila_painting', 'knitting')),
  type            TEXT          NOT NULL CHECK (type IN ('ready_to_ship', 'made_to_order')),
  size            TEXT,
  images          TEXT[]        NOT NULL DEFAULT '{}',           -- Array of Supabase Storage URLs
  is_featured     BOOLEAN       NOT NULL DEFAULT FALSE,
  created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

-- Indexes for common queries
CREATE INDEX idx_products_category    ON products (category);
CREATE INDEX idx_products_type        ON products (type);
CREATE INDEX idx_products_is_featured ON products (is_featured);
CREATE INDEX idx_products_created_at  ON products (created_at DESC);

-- ============================================================
-- 2. ORDERS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS orders (
  id                  UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name       TEXT          NOT NULL,
  customer_email      TEXT          NOT NULL,
  customer_phone      TEXT,
  shipping_address    TEXT          NOT NULL,
  total_amount        NUMERIC(10,2) NOT NULL CHECK (total_amount >= 0),
  razorpay_order_id   TEXT          UNIQUE,                      -- Set after Razorpay order creation
  razorpay_payment_id TEXT          UNIQUE,                      -- Set after successful payment
  payment_status      TEXT          NOT NULL DEFAULT 'pending'
                        CHECK (payment_status IN ('pending', 'captured', 'failed')),
  production_status   TEXT          NOT NULL DEFAULT 'received'
                        CHECK (production_status IN ('received', 'painting', 'shipped', 'delivered')),
  created_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

-- Indexes for order lookups and admin dashboard
CREATE INDEX idx_orders_customer_email     ON orders (customer_email);
CREATE INDEX idx_orders_razorpay_order_id  ON orders (razorpay_order_id);
CREATE INDEX idx_orders_payment_status     ON orders (payment_status);
CREATE INDEX idx_orders_production_status  ON orders (production_status);
CREATE INDEX idx_orders_created_at         ON orders (created_at DESC);

-- ============================================================
-- 3. ORDER ITEMS TABLE
-- ============================================================
CREATE TABLE IF NOT EXISTS order_items (
  id                  BIGINT        PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  order_id            UUID          NOT NULL REFERENCES orders(id)   ON DELETE CASCADE,
  product_id          UUID          NOT NULL REFERENCES products(id)  ON DELETE RESTRICT,
  quantity            INTEGER       NOT NULL CHECK (quantity > 0),
  price_at_purchase   NUMERIC(10,2) NOT NULL CHECK (price_at_purchase >= 0)
);

-- Indexes for joins
CREATE INDEX idx_order_items_order_id   ON order_items (order_id);
CREATE INDEX idx_order_items_product_id ON order_items (product_id);

-- ============================================================
-- ROW-LEVEL SECURITY (RLS)
-- ============================================================

-- Products: public read, service-role write only
ALTER TABLE products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Products are publicly readable"
  ON products FOR SELECT
  USING (TRUE);

-- Orders: customers can insert; only service role can read all
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can create an order"
  ON orders FOR INSERT
  WITH CHECK (TRUE);

CREATE POLICY "Customers can read their own orders by email"
  ON orders FOR SELECT
  USING (TRUE);  -- Filtered at API layer by razorpay_order_id or email

-- Order Items: same as orders
ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Order items are insertable with an order"
  ON order_items FOR INSERT
  WITH CHECK (TRUE);

CREATE POLICY "Order items are readable"
  ON order_items FOR SELECT
  USING (TRUE);

-- ============================================================
-- STORAGE BUCKET (run separately in Supabase Dashboard
-- or via the Storage API)
-- ============================================================
-- Bucket name : product-images
-- Public      : true
-- File size   : 5 MB max (free tier)
-- Allowed MIME: image/jpeg, image/png, image/webp

-- ============================================================
-- SEED DATA — sample Mithila painting + knitting product
-- ============================================================
INSERT INTO products (title, description, story, price, category, type, size, images, is_featured)
VALUES
(
  'Madhubani Fish Pair',
  'Hand-painted on handmade paper using natural pigments. Two fish intertwined in the classic Mithila style.',
  'The fish (Matsya) is one of the most sacred symbols in Mithila art, representing fertility, prosperity, and the life-giving waters of the Ganga. Painted traditionally during weddings and festivals.',
  2800.00,
  'mithila_painting',
  'ready_to_ship',
  '12" x 16"',
  ARRAY['https://your-project.supabase.co/storage/v1/object/public/product-images/placeholder.jpg'],
  TRUE
),
(
  'Goddess Durga — Navratri Painting',
  'A bold, detailed depiction of Ma Durga riding her lion, painted with earthy reds and blacks on canvas.',
  'Durga Puja paintings in Mithila tradition trace back centuries. Each artist family carries a unique line style passed down through generations of women, painted with twigs, fingers, and homemade ink.',
  4500.00,
  'mithila_painting',
  'made_to_order',
  '18" x 24"',
  ARRAY['https://your-project.supabase.co/storage/v1/object/public/product-images/placeholder.jpg'],
  TRUE
),
(
  'Handknit Wool Throw — Earthy Stripes',
  'A cosy, medium-weight throw knitted in earthy ochre and ivory stripes. Perfect for cool evenings.',
  'Knitted with the same meditative patience as Mithila painting — every stitch is intentional.',
  1600.00,
  'knitting',
  'ready_to_ship',
  '50" x 60"',
  ARRAY['https://your-project.supabase.co/storage/v1/object/public/product-images/placeholder.jpg'],
  FALSE
);
